import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dados-faturamento',
  templateUrl: './dados-faturamento.component.html',
  styleUrls: ['./dados-faturamento.component.css']
})
export class DadosFaturamentoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
