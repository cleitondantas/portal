export class Municipio{
    codMunicipio:number;
    codEstado:number;
    descMunicipio:string;
}