export class AreaUsuarios{
    codAreaUsuario:string;
    descArea:string;
    isAtivo:boolean;
    
}