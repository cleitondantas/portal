import { Usuario } from './usuario';

export class CurrentUser {
    public token: string;
    public usuario: Usuario;
  }
  