export class Area {
    codArea:number;
    descAreaCadastro:string;
    isAtivo:boolean;
}