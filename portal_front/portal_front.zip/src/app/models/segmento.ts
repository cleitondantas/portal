import { Area } from "./area";

export class Segmento{
    codSegmento:number;
    area:Area;
    descSegmento:string;
    isAtivo:boolean;
}