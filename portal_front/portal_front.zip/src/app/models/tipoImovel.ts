export class TipoImovel{
    codTipoImovel:number;
    descTipoImovel:string;
}