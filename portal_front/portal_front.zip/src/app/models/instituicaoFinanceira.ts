export class InstiruicaoFinanceiras{
    
    codInstituicaoFinanceira:number;
    descInstituicaoFinanceira:string;

}