export class Contatos {
    codtipocontato: string;
    cpfcnpj: string;
    desccontato: string;
}
