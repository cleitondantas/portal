import { Area } from "./area";

export class Status {
    codStatus:number;
    area:Area;
    descStatus:string;
    isAtivo:boolean;

}