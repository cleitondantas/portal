import { Area } from "./area";

export class SubStatus{

    codSubStatus:number;
    area:Area;
    descSubStatus:string;
    isAtivo:boolean;
    
}