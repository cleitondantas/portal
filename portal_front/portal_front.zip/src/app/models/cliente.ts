export class Cliente {

    numDocumento:string;
    nomeCliente: string;
    numDocumentoCo: string;
    nomeClienteCo: string;
    dtCadastro:string;

}