export class PerfilUsuario{
    codPerfilUsuario:number;
    descPerfil:string;
    isAtivo:boolean;
}