import { EmpresaGrupoEconomico } from "./empresaGrupoEconomico";

export class Empreendimento{
    codEmpreendimento:number;
    empresaGrupoEconomico:EmpresaGrupoEconomico;
    descEmpreendimento:string;
    
}