export class Role {
    id:number;
    profile:string;
    nivel:number
}
