import { Area } from "./area";

export class Canal {
    area: Area;
    codCanal:number;
    isAtivo:boolean;
    
}