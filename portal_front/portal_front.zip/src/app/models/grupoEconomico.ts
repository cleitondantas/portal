export class GrupoEconomico{
    codGrupoEconomico:number;
    cnpjGrupoEconomico:string;
    descGrupoEconomico:string;


}