import { Area } from "./area";

export class Modalidade {
    codModalidade:number;
    area:Area;
    descModalidade:string;
    isAtivo:boolean;


}