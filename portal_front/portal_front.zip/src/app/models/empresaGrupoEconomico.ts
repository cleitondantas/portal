import { GrupoEconomico } from "./grupoEconomico";

export class EmpresaGrupoEconomico{

    codEmpresaGrupoEconomico:number;
    grupoEconomico:GrupoEconomico;
    cnpjEmpresaGrupoEconomico:string;
    descEmpresaGrupoEconomico:string;
    
}