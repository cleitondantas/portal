import { Router } from '@angular/router';


export const environment = {
  production: true,
  urlpath:'',
};
